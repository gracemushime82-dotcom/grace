// --- SavingsAccount Class ---
class SavingsAccount extends Account {
    private double rate; // e.g., 0.05 for 5%

    public SavingsAccount(String accountNo, double opening, double rate) {
        super(accountNo, opening);
        this.rate = rate;
    }

    @Override
    public boolean withdraw(double amount) {
        // Refuse if it takes the balance below zero
        if (amount > 0 && (this.balance - amount) >= 0) {
            this.balance -= amount;
            return true;
        }
        return false;
    }

    public void addInterest() {
        // Adds rate% of the balance to the balance (e.g., balance * rate)
        this.balance += (this.balance * this.rate);
    }
}

// --- CurrentAccount Class ---
class CurrentAccount extends Account {
    private double overdraft; // Represented as a positive limit (e.g., 500)

    public CurrentAccount(String accountNo, double opening, double overdraft) {
        super(accountNo, opening);
        this.overdraft = overdraft;
    }

    @Override
    public boolean withdraw(double amount) {
        // May take balance negative but only as far as overdraft limit
        if (amount > 0 && (this.balance - amount) >= -overdraft) {
            this.balance -= amount;
            return true;
        }
        return false;
    }
}