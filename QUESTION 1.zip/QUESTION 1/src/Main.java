public class Main {
    public static void main(String[] args) {
        System.out.println("=== Running Account Module Verification ===\n");

        // 1. Create a Customer
        Customer customer = new Customer("Alex");

        // 2. Create a SavingsAccount (Opening balance: 1000, Interest rate: 5% or 0.05)
        SavingsAccount savings = new SavingsAccount("SAV-001", 1000.0, 0.05);

        // 3. Create a CurrentAccount (Opening balance: 500, Overdraft limit: 300)
        CurrentAccount current = new CurrentAccount("CUR-002", 500.0, 300.0);

        // 4. Associate accounts with the customer (Aggregation)
        customer.addAccount(savings);
        customer.addAccount(current);

        // 5. Test SavingsAccount Logic
        System.out.println("--- Testing Savings Account ---");
        System.out.println(savings.generateStatement());

        // Try to withdraw more than the balance (Should fail/return false)
        boolean savingsWithdrawFail = savings.withdraw(1200.0);
        System.out.println("Withdraw 1200 (Expect false): " + savingsWithdrawFail);

        // Withdraw valid amount
        boolean savingsWithdrawSuccess = savings.withdraw(200.0);
        System.out.println("Withdraw 200 (Expect true): " + savingsWithdrawSuccess);
        System.out.println("After withdrawal: " + savings.generateStatement());

        // Add interest (5% of remaining 800 is 40)
        savings.addInterest();
        System.out.println("After adding 5% interest (Expect balance 840): " + savings.generateStatement());
        System.out.println();

        // 6. Test CurrentAccount Logic
        System.out.println("--- Testing Current Account ---");
        System.out.println(current.generateStatement());

        // Withdraw into overdraft but within limit (Balance: 500 - 700 = -200, which is >= -300)
        boolean currentWithdrawSuccess = current.withdraw(700.0);
        System.out.println("Withdraw 700 (Expect true, goes into overdraft): " + currentWithdrawSuccess);
        System.out.println("Current Account Status: " + current.generateStatement());

        // Try to exceed overdraft limit (Balance: -200 - 200 = -400, which exceeds -300 limit)
        boolean currentWithdrawFail = current.withdraw(200.0);
        System.out.println("Withdraw another 200 (Expect false, exceeds overdraft): " + currentWithdrawFail);
        System.out.println();

        // 7. Verify Customer Total Worth
        // Savings (840) + Current (-200) = 640
        System.out.println("--- Testing Customer Total Worth ---");
        System.out.println("Total Worth for Customer " + "Alex: " + customer.totalWorth());
    }
}