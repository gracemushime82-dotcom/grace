// --- Statement Interface ---
interface Statement {
    String generateStatement();
}

// --- Abstract Account Class ---
abstract class Account implements Statement {
    protected String accountNo;
    protected double balance;

    // Constructor
    public Account(String accountNo, double opening) {
        this.accountNo = accountNo;
        this.balance = opening;
    }

    // Concrete method
    public void deposit(double amount) {
        if (amount > 0) {
            this.balance += amount;
        }
    }

    // Abstract method (Note the {abstract} tag in UML)
    public abstract boolean withdraw(double amount);

    public double getBalance() {
        return this.balance;
    }

    // Sensible implementation requested in part (b)
    @Override
    public String generateStatement() {
        return "Account Number: " + accountNo + ", Current Balance: " + balance;
    }
}