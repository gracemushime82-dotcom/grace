import java.util.ArrayList;
import java.util.List;

// --- Customer Class ---
class Customer {
    private String name;
    private List<Account> accounts;

    public Customer(String name) {
        this.name = name;
        this.accounts = new ArrayList<>();
    }

    public void addAccount(Account a) {
        if (a != null) {
            this.accounts.add(a);
        }
    }

    public double totalWorth() {
        double total = 0;
        for (Account acc : accounts) {
            total += acc.getBalance();
        }
        return total;
    }
}